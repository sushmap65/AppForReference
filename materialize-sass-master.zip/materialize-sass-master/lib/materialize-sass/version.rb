module Materialize
  module Sass
    VERSION = "0.99.0"
  end
end

